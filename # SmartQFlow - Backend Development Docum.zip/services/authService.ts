/**
 * Authentication Service - Complete Supabase Integration
 * Handles: Patient Auth, Staff Auth, Doctor Auth, Session Management
 */

import { createClient, SupabaseClient, Session } from '@supabase/supabase-js';
import { UserRole } from '../types';

interface AuthUser {
  clinic_id: string;
  id: string;
  email: string;
  phone?: string;
  name: string;
  role: UserRole;
  clinicId?: string;
  isVerified: boolean;
  createdAt: string;
  metadata?: Record<string, any>;
}

interface LoginCredentials {
  email: string;
  password: string;
}

interface SignupData extends LoginCredentials {
  name: string;
  phone: string;
  role: UserRole;
  clinicId?: string;
}

class AuthService {
  private supabase: SupabaseClient | null = null;
  private currentUser: AuthUser | null = null;
  private session: Session | null = null;
  private authStateChangeListeners: ((user: AuthUser | null) => void)[] = [];

  /**
   * Initialize with Supabase credentials
   * Call this on app startup with proper env variables
   */
  initialize(supabaseUrl: string, supabaseKey: string) {
    try {
      this.supabase = createClient(supabaseUrl, supabaseKey);
      this.setupAuthStateListener();
      this.restoreSession();
    } catch (error) {
      console.error('Failed to initialize Supabase Auth:', error);
    }
  }

  /**
   * Setup Supabase auth state listener
   */
  private setupAuthStateListener() {
    if (!this.supabase) return;

    this.supabase.auth.onAuthStateChange(async (event, session) => {
      this.session = session;
      if (session?.user) {
        await this.loadUserProfile(session.user.id);
      } else {
        this.currentUser = null;
      }
      this.notifyListeners();
    });
  }

  /**
   * Restore session from Supabase (auto-login on page refresh)
   */
  private async restoreSession() {
    if (!this.supabase) return;

    try {
      const { data: { session } } = await this.supabase.auth.getSession();
      if (session?.user) {
        this.session = session;
        await this.loadUserProfile(session.user.id);
      }
    } catch (error) {
      console.error('Failed to restore session:', error);
    }
  }

  /**
   * Load user profile from database, create if doesn't exist
   */
  private async loadUserProfile(userId: string) {
    if (!this.supabase) return;

    try {
      const { data, error } = await this.supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        // Profile doesn't exist, try to create it from auth metadata
        await this.createUserProfile(userId);
        // Retry loading
        const { data: newData, error: newError } = await this.supabase
          .from('user_profiles')
          .select('*')
          .eq('id', userId)
          .single();

        if (newError) throw newError;
        // Use newData for the rest of the function
        this.currentUser = {
          id: newData.id,
          email: newData.email,
          phone: newData.phone,
          name: newData.name,
          role: newData.role,
          clinicId: newData.clinic_id,
          isVerified: newData.is_verified,
          createdAt: newData.created_at,
          metadata: newData.metadata
        };
        return;
      }

    } catch (error) {
      console.error('Failed to load user profile:', error);
    }
  }

  /**
   * Create user profile from auth user metadata
   */
  private async createUserProfile(userId: string) {
    if (!this.supabase) return;

    try {
      const { data: authUser, error: authError } = await this.supabase.auth.getUser();
      if (authError || !authUser.user) throw authError;

      const userMetadata = authUser.user.user_metadata || {};
      const appMetadata = authUser.user.app_metadata || {};

      const { error } = await this.supabase
        .from('user_profiles')
        .insert({
          id: userId,
          email: authUser.user.email,
          name: userMetadata.name || 'Unknown',
          phone: userMetadata.phone,
          role: userMetadata.role || 'PATIENT',
          clinic_id: userMetadata.clinic_id,
          is_verified: appMetadata.email_confirmed_at ? true : false
        });

      if (error) throw error;
    } catch (error) {
      console.error('Failed to create user profile:', error);
    }
  }

  /**
   * Sign up new user (Patient, Staff, Doctor)
   */
  async signup(data: SignupData): Promise<{ success: boolean; error?: string; user?: AuthUser }> {
    if (!this.supabase) {
      return { success: false, error: 'Auth service not initialized' };
    }

    try {
      // 1. Create Supabase auth user
      const { data: authData, error: authError } = await this.supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            name: data.name,
            phone: data.phone,
            role: data.role,
            clinic_id: data.clinicId
          }
        }
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error('User creation failed');

      // 2. If user is confirmed and has session, load/create profile
      if (authData.session) {
        this.session = authData.session;
        await this.loadUserProfile(authData.user.id);
        return {
          success: true,
          user: this.currentUser!
        };
      } else {
        // Email confirmation required - profile will be created on first login
        return {
          success: true,
          error: 'Please check your email to confirm your account before logging in.'
        };
      }
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Signup failed'
      };
    }
  }

  /**
   * Login user
   */
  async login(credentials: LoginCredentials): Promise<{ success: boolean; error?: string; user?: AuthUser }> {
    if (!this.supabase) {
      return { success: false, error: 'Auth service not initialized' };
    }

    try {
      const { data, error } = await this.supabase.auth.signInWithPassword({
        email: credentials.email,
        password: credentials.password
      });

      if (error) throw error;
      if (!data.user) throw new Error('Login failed');

      this.session = data.session;
      await this.loadUserProfile(data.user.id);

      return {
        success: true,
        user: this.currentUser!
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Login failed'
      };
    }
  }

  /**
   * Login with phone (OTP-based) - Optional for patients
   */
  async loginWithPhone(phone: string): Promise<{ success: boolean; error?: string }> {
    if (!this.supabase) {
      return { success: false, error: 'Auth service not initialized' };
    }

    try {
      const { error } = await this.supabase.auth.signInWithOtp({
        phone: phone
      });

      if (error) throw error;

      return { success: true };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Phone login failed'
      };
    }
  }

  /**
   * Verify OTP for phone auth
   */
  async verifyOtp(phone: string, token: string): Promise<{ success: boolean; error?: string; user?: AuthUser }> {
    if (!this.supabase) {
      return { success: false, error: 'Auth service not initialized' };
    }

    try {
      const { data, error } = await this.supabase.auth.verifyOtp({
        phone: phone,
        token: token,
        type: 'sms'
      });

      if (error) throw error;
      if (!data.user) throw new Error('OTP verification failed');

      this.session = data.session;
      await this.loadUserProfile(data.user.id);

      return {
        success: true,
        user: this.currentUser!
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'OTP verification failed'
      };
    }
  }

  /**
   * Update user profile
   */
  async updateProfile(updates: Partial<AuthUser>): Promise<{ success: boolean; error?: string }> {
    if (!this.supabase || !this.currentUser) {
      return { success: false, error: 'Not authenticated' };
    }

    try {
      const { error } = await this.supabase
        .from('user_profiles')
        .update({
          name: updates.name,
          phone: updates.phone,
          metadata: updates.metadata
        })
        .eq('id', this.currentUser.id);

      if (error) throw error;

      // Reload profile
      await this.loadUserProfile(this.currentUser.id);

      return { success: true };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Update failed'
      };
    }
  }

  /**
   * Change password
   */
  async changePassword(newPassword: string): Promise<{ success: boolean; error?: string }> {
    if (!this.supabase) {
      return { success: false, error: 'Auth service not initialized' };
    }

    try {
      const { error } = await this.supabase.auth.updateUser({
        password: newPassword
      });

      if (error) throw error;

      return { success: true };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Password change failed'
      };
    }
  }

  /**
   * Send password reset email
   */
  async sendPasswordResetEmail(email: string): Promise<{ success: boolean; error?: string }> {
    if (!this.supabase) {
      return { success: false, error: 'Auth service not initialized' };
    }

    try {
      const { error } = await this.supabase.auth.resetPasswordForEmail(email);
      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Password reset failed'
      };
    }
  }

  /**
   * Logout current user
   */
  async logout(): Promise<{ success: boolean; error?: string }> {
    if (!this.supabase) {
      return { success: false, error: 'Auth service not initialized' };
    }

    try {
      const { error } = await this.supabase.auth.signOut();
      if (error) throw error;

      this.currentUser = null;
      this.session = null;
      this.notifyListeners();

      return { success: true };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Logout failed'
      };
    }
  }

  /**
   * Get current user
   */
  getCurrentUser(): AuthUser | null {
    return this.currentUser;
  }

  /**
   * Get current session
   */
  getSession(): Session | null {
    return this.session;
  }

  /**
   * Check if user is authenticated
   */
  isAuthenticated(): boolean {
    return !!this.currentUser && !!this.session;
  }

  /**
   * Get access token for API requests
   */
  getAccessToken(): string | null {
    return this.session?.access_token || null;
  }

  /**
   * Subscribe to auth state changes
   */
  onAuthStateChange(callback: (user: AuthUser | null) => void): () => void {
    this.authStateChangeListeners.push(callback);
    // Return unsubscribe function
    return () => {
      this.authStateChangeListeners = this.authStateChangeListeners.filter(
        listener => listener !== callback
      );
    };
  }

  /**
   * Notify all listeners of auth state change
   */
  private notifyListeners() {
    this.authStateChangeListeners.forEach(listener => {
      listener(this.currentUser);
    });
  }

  /**
   * Get Supabase client instance (for advanced queries)
   */
  getSupabase(): SupabaseClient | null {
    return this.supabase;
  }
}

// Export singleton instance
export const authService = new AuthService();

export type { AuthUser, LoginCredentials, SignupData };
